const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../utils/db');
const { encrypt } = require('../utils/crypto');
const { authMiddleware, requireRole } = require('../middleware/auth');
const { syncTenant } = require('../services/syncService');

const router = express.Router();
router.use(authMiddleware);

/**
 * POST /api/admin/sync   (manual)
 * Body: { daysBack: 7 }
 */
router.post('/sync', requireRole('admin'), async (req, res, next) => {
  try {
    const daysBack = parseInt(req.body.daysBack || '1');
    // Disparar async — no esperar a que termine
    syncTenant(req.user.tenantId, daysBack).catch(err =>
      console.error('Sync manual fallido:', err)
    );
    res.json({ success: true, message: 'Sincronización iniciada en segundo plano' });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/admin/tenant-settings
 * Configurar API key del PBX (solo admin)
 */
router.post('/tenant-settings', requireRole('admin'), async (req, res, next) => {
  try {
    const { pbxApiKey, pbxHost, pbxServerId } = req.body;
    if (!pbxApiKey || pbxApiKey.length < 10) {
      return res.status(400).json({ error: 'pbxApiKey debe tener al menos 10 caracteres' });
    }

    const encrypted = encrypt(pbxApiKey);
    const updates = ['pbx_api_key_encrypted = $1'];
    const params = [encrypted];
    let idx = 2;

    if (pbxHost) { updates.push(`pbx_host = $${idx++}`); params.push(pbxHost); }
    if (pbxServerId) { updates.push(`pbx_server_id = $${idx++}`); params.push(parseInt(pbxServerId)); }

    params.push(req.user.tenantId);
    await db.query(
      `UPDATE tenants SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = $${idx}`,
      params
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/admin/users
 */
router.get('/users', requireRole('admin'), async (req, res, next) => {
  try {
    const { rows } = await db.query(
      'SELECT id, username, email, role, is_active, last_login, created_at FROM users WHERE tenant_id = $1 ORDER BY created_at DESC',
      [req.user.tenantId]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/admin/users
 * Crear usuario nuevo
 */
router.post('/users', requireRole('admin'), async (req, res, next) => {
  try {
    const { username, email, password, role = 'viewer' } = req.body;
    if (!username || !email || !password || password.length < 8) {
      return res.status(400).json({ error: 'Datos inválidos (password mínimo 8 caracteres)' });
    }
    if (!['admin', 'manager', 'viewer'].includes(role)) {
      return res.status(400).json({ error: 'Role inválido' });
    }

    const hash = await bcrypt.hash(password, 10);
    const { rows } = await db.query(
      `INSERT INTO users (tenant_id, username, email, password_hash, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, username, email, role`,
      [req.user.tenantId, username, email, hash, role]
    );
    res.json(rows[0]);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Usuario o email ya existe' });
    next(err);
  }
});

module.exports = router;
