const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../utils/db');
const { signToken, authMiddleware } = require('../middleware/auth');

const router = express.Router();

/**
 * POST /api/auth/login
 * Body: { tenantCode, username, password }
 */
router.post('/login', async (req, res, next) => {
  try {
    const { tenantCode, username, password } = req.body;
    if (!tenantCode || !username || !password) {
      return res.status(400).json({ error: 'tenantCode, username y password son obligatorios' });
    }

    const { rows } = await db.query(
      `SELECT u.id, u.username, u.password_hash, u.role, u.tenant_id, t.name as tenant_name, t.tenant_code
       FROM users u
       JOIN tenants t ON u.tenant_id = t.id
       WHERE t.tenant_code = $1 AND u.username = $2 AND u.is_active = true AND t.is_active = true`,
      [tenantCode, username]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const user = rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    await db.query('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1', [user.id]);

    const token = signToken({
      userId: user.id,
      tenantId: user.tenant_id,
      role: user.role,
      username: user.username,
    });

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        tenantId: user.tenant_id,
        tenantName: user.tenant_name,
        tenantCode: user.tenant_code,
      },
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/auth/me
 */
router.get('/me', authMiddleware, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT u.id, u.username, u.email, u.role, t.id as tenant_id, t.name as tenant_name, t.tenant_code
       FROM users u JOIN tenants t ON u.tenant_id = t.id
       WHERE u.id = $1`,
      [req.user.userId]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/auth/change-password
 */
router.post('/change-password', authMiddleware, async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'newPassword debe tener al menos 8 caracteres' });
    }

    const { rows } = await db.query('SELECT password_hash FROM users WHERE id = $1', [req.user.userId]);
    if (rows.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });

    const valid = await bcrypt.compare(currentPassword, rows[0].password_hash);
    if (!valid) return res.status(401).json({ error: 'Password actual incorrecta' });

    const newHash = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, req.user.userId]);

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
