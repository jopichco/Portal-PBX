const express = require('express');
const db = require('../utils/db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware);

/**
 * GET /api/calls?from=...&to=...&status=...&direction=...&extension=...&department=...&page=1&limit=50
 */
router.get('/', async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;
    const {
      from, to, status, direction, extension, department,
    } = req.query;
    const page = Math.max(parseInt(req.query.page || '1'), 1);
    const limit = Math.min(parseInt(req.query.limit || '50'), 500);
    const offset = (page - 1) * limit;

    const where = ['c.tenant_id = $1'];
    const params = [tenantId];
    let idx = 2;

    if (from) { where.push(`c.start_datetime >= $${idx++}`); params.push(from); }
    if (to)   { where.push(`c.start_datetime <= $${idx++}`); params.push(to); }
    if (status) { where.push(`c.status = $${idx++}`); params.push(status); }
    if (direction) { where.push(`c.direction = $${idx++}`); params.push(direction); }
    if (extension) {
      where.push(`(c.to_extension = $${idx} OR c.from_extension = $${idx})`);
      params.push(extension);
      idx++;
    }
    if (department) { where.push(`c.department_id = $${idx++}`); params.push(parseInt(department)); }

    const whereSql = where.join(' AND ');

    const countResult = await db.query(
      `SELECT COUNT(*) FROM cdrs c WHERE ${whereSql}`,
      params
    );

    const dataResult = await db.query(
      `SELECT
        c.id, c.unique_id, c.from_number, c.from_extension, c.to_number, c.to_extension,
        c.start_datetime, c.duration, c.billing_duration, c.cost, c.status, c.direction,
        c.recording_available, c.caller_id, c.mos,
        d.name AS department_name
      FROM cdrs c
      LEFT JOIN departments d ON c.department_id = d.pbx_department_id AND d.tenant_id = c.tenant_id
      WHERE ${whereSql}
      ORDER BY c.start_datetime DESC
      LIMIT $${idx++} OFFSET $${idx++}`,
      [...params, limit, offset]
    );

    res.json({
      total: parseInt(countResult.rows[0].count),
      page, limit,
      data: dataResult.rows,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
