const express = require('express');
const db = require('../utils/db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware);

/**
 * GET /api/dashboard/summary
 * Devuelve totales para hoy, ayer, semana actual, semana pasada, mes actual, mes anterior
 */
router.get('/summary', async (req, res, next) => {
  try {
    const tenantId = req.user.tenantId;

    const { rows } = await db.query(`
      SELECT
        COUNT(*) FILTER (WHERE start_datetime >= CURRENT_DATE) AS today,
        COUNT(*) FILTER (WHERE start_datetime >= CURRENT_DATE - INTERVAL '1 day' AND start_datetime < CURRENT_DATE) AS yesterday,
        COUNT(*) FILTER (WHERE start_datetime >= date_trunc('week', CURRENT_DATE)) AS this_week,
        COUNT(*) FILTER (WHERE start_datetime >= date_trunc('week', CURRENT_DATE) - INTERVAL '1 week'
                          AND start_datetime < date_trunc('week', CURRENT_DATE)) AS last_week,
        COUNT(*) FILTER (WHERE start_datetime >= date_trunc('month', CURRENT_DATE)) AS this_month,
        COUNT(*) FILTER (WHERE start_datetime >= date_trunc('month', CURRENT_DATE) - INTERVAL '1 month'
                          AND start_datetime < date_trunc('month', CURRENT_DATE)) AS last_month,
        COUNT(*) FILTER (WHERE status = 'Answered' AND start_datetime >= date_trunc('month', CURRENT_DATE)) AS answered_month,
        COUNT(*) FILTER (WHERE status != 'Answered' AND start_datetime >= date_trunc('month', CURRENT_DATE)) AS missed_month,
        COALESCE(AVG(duration) FILTER (WHERE status = 'Answered' AND start_datetime >= date_trunc('month', CURRENT_DATE)), 0)::INT AS avg_duration_month
      FROM cdrs
      WHERE tenant_id = $1
    `, [tenantId]);

    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/dashboard/calls-by-day?days=30
 * Volumen de llamadas por día
 */
router.get('/calls-by-day', async (req, res, next) => {
  try {
    const days = Math.min(parseInt(req.query.days || '30'), 365);
    const { rows } = await db.query(`
      SELECT
        DATE(start_datetime) AS date,
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE status = 'Answered') AS answered,
        COUNT(*) FILTER (WHERE status != 'Answered') AS missed
      FROM cdrs
      WHERE tenant_id = $1
        AND start_datetime >= CURRENT_DATE - ($2 || ' days')::INTERVAL
      GROUP BY DATE(start_datetime)
      ORDER BY date ASC
    `, [req.user.tenantId, days]);
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/dashboard/calls-by-hour
 * Distribución de llamadas por hora del día (últimos 7 días)
 */
router.get('/calls-by-hour', async (req, res, next) => {
  try {
    const { rows } = await db.query(`
      SELECT
        EXTRACT(HOUR FROM start_datetime)::INT AS hour,
        COUNT(*) AS total
      FROM cdrs
      WHERE tenant_id = $1
        AND start_datetime >= CURRENT_DATE - INTERVAL '7 days'
      GROUP BY hour
      ORDER BY hour ASC
    `, [req.user.tenantId]);
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/dashboard/calls-by-department?period=month
 * Llamadas agrupadas por departamento
 */
router.get('/calls-by-department', async (req, res, next) => {
  try {
    const period = req.query.period || 'month';  // today, week, month
    let interval;
    switch (period) {
      case 'today': interval = "start_datetime >= CURRENT_DATE"; break;
      case 'week': interval = "start_datetime >= date_trunc('week', CURRENT_DATE)"; break;
      case 'month': default: interval = "start_datetime >= date_trunc('month', CURRENT_DATE)";
    }

    const { rows } = await db.query(`
      SELECT
        COALESCE(d.name, 'Sin Departamento') AS department,
        d.id AS department_id,
        COUNT(c.*) AS total,
        COUNT(c.*) FILTER (WHERE c.status = 'Answered') AS answered,
        COUNT(c.*) FILTER (WHERE c.status != 'Answered') AS missed,
        COUNT(c.*) FILTER (WHERE c.direction = 'Incoming') AS incoming,
        COUNT(c.*) FILTER (WHERE c.direction = 'Outgoing') AS outgoing,
        COALESCE(AVG(c.duration) FILTER (WHERE c.status = 'Answered'), 0)::INT AS avg_duration
      FROM cdrs c
      LEFT JOIN departments d ON c.department_id = d.pbx_department_id AND d.tenant_id = c.tenant_id
      WHERE c.tenant_id = $1 AND ${interval}
      GROUP BY d.id, d.name
      ORDER BY total DESC
    `, [req.user.tenantId]);

    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/dashboard/calls-by-user?period=month&limit=20
 * Top usuarios por llamadas recibidas
 */
router.get('/calls-by-user', async (req, res, next) => {
  try {
    const period = req.query.period || 'month';
    const limit = Math.min(parseInt(req.query.limit || '20'), 100);

    let interval;
    switch (period) {
      case 'today': interval = "c.start_datetime >= CURRENT_DATE"; break;
      case 'week': interval = "c.start_datetime >= date_trunc('week', CURRENT_DATE)"; break;
      case 'month': default: interval = "c.start_datetime >= date_trunc('month', CURRENT_DATE)";
    }

    const { rows } = await db.query(`
      SELECT
        e.extension_number,
        e.name AS user_name,
        COUNT(c.*) FILTER (WHERE c.to_extension = e.extension_number) AS received,
        COUNT(c.*) FILTER (WHERE c.from_extension = e.extension_number) AS made,
        COUNT(c.*) FILTER (WHERE c.to_extension = e.extension_number AND c.status = 'Answered') AS answered,
        COUNT(c.*) FILTER (WHERE c.to_extension = e.extension_number AND c.status != 'Answered') AS missed,
        COALESCE(AVG(c.duration) FILTER (WHERE c.to_extension = e.extension_number AND c.status = 'Answered'), 0)::INT AS avg_duration
      FROM extensions e
      LEFT JOIN cdrs c ON c.tenant_id = e.tenant_id
        AND (c.to_extension = e.extension_number OR c.from_extension = e.extension_number)
        AND ${interval}
      WHERE e.tenant_id = $1
      GROUP BY e.id, e.extension_number, e.name
      HAVING COUNT(c.*) > 0
      ORDER BY received DESC, made DESC
      LIMIT $2
    `, [req.user.tenantId, limit]);

    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/dashboard/calls-by-weekday
 */
router.get('/calls-by-weekday', async (req, res, next) => {
  try {
    const { rows } = await db.query(`
      SELECT
        EXTRACT(DOW FROM start_datetime)::INT AS day_num,
        TO_CHAR(start_datetime, 'Day') AS day_name,
        COUNT(*) AS total
      FROM cdrs
      WHERE tenant_id = $1
        AND start_datetime >= CURRENT_DATE - INTERVAL '30 days'
      GROUP BY day_num, day_name
      ORDER BY day_num
    `, [req.user.tenantId]);
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/dashboard/sync-status
 */
router.get('/sync-status', async (req, res, next) => {
  try {
    const { rows } = await db.query(
      'SELECT sync_type, last_sync_at, last_sync_status, records_synced, last_error FROM sync_status WHERE tenant_id = $1',
      [req.user.tenantId]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
