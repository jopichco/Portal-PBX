require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const callsRoutes = require('./routes/calls');
const adminRoutes = require('./routes/admin');
const { startScheduler } = require('./services/scheduler');
const { initDb } = require('./utils/db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Rate limit general
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/calls', callsRoutes);
app.use('/api/admin', adminRoutes);

// Manejador de errores
app.use((err, req, res, next) => {
  console.error('[ERROR]', err);
  res.status(err.status || 500).json({
    error: err.message || 'Error interno del servidor'
  });
});

// Arranque
(async () => {
  try {
    await initDb();
    console.log('[DB] Conexión establecida');

    startScheduler();
    console.log('[SCHEDULER] Iniciado');

    app.listen(PORT, () => {
      console.log(`[SERVER] Escuchando en puerto ${PORT}`);
    });
  } catch (err) {
    console.error('[FATAL] No se pudo iniciar el servidor:', err);
    process.exit(1);
  }
})();
