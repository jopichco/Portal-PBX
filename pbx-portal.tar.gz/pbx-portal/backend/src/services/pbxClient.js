const axios = require('axios');

/**
 * Cliente para la API de PBXware
 * Documentación: protocolo HTTP GET/POST con apikey y action
 */
class PbxClient {
  constructor({ host, apiKey, serverId }) {
    this.host = host;
    this.apiKey = apiKey;
    this.serverId = serverId;
    this.baseUrl = `https://${host}/`;
  }

  async request(action, params = {}) {
    try {
      const response = await axios.get(this.baseUrl, {
        params: {
          apikey: this.apiKey,
          action,
          apiformat: 'json',
          ...params,
        },
        timeout: 30000,
        // PBXware suele usar certificados autofirmados internos
        httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false }),
      });

      if (response.data && response.data.error) {
        throw new Error(`PBX API: ${response.data.error}`);
      }

      return response.data;
    } catch (err) {
      if (err.response) {
        throw new Error(`PBX HTTP ${err.response.status}: ${err.response.statusText}`);
      }
      throw err;
    }
  }

  // ============ Extensiones ============
  async listExtensions() {
    return this.request('pbxware.ext.list', { server: this.serverId });
  }

  // ============ Departamentos ============
  async listDepartments() {
    return this.request('pbxware.department.list', { server: this.serverId });
  }

  // ============ CDRs ============
  async downloadCdrs({ start, end, starttime = '00:00:00', endtime = '23:59:59', page = 1, limit = 1000, cdrtype = 3 }) {
    return this.request('pbxware.cdr.download', {
      server: this.serverId,
      start,
      end,
      starttime,
      endtime,
      page,
      limit,
      cdrtype,
    });
  }

  // ============ Dashboard (tiempo real) ============
  async getDashboardCalls() {
    return this.request('pbxware.dashboard.calls', { server: this.serverId });
  }

  async getExtensionsOnline() {
    return this.request('pbxware.dashboard.ext_online', { server: this.serverId });
  }
}

/**
 * Formatea una fecha JS a "Mmm-dd-YYYY" como exige PBXware
 */
function formatPbxDate(date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const m = months[date.getMonth()];
  const d = String(date.getDate()).padStart(2, '0');
  const y = date.getFullYear();
  return `${m}-${d}-${y}`;
}

module.exports = { PbxClient, formatPbxDate };
