const cron = require('node-cron');
const { syncAllTenants } = require('./syncService');

function startScheduler() {
  const intervalMin = parseInt(process.env.SYNC_INTERVAL_MINUTES || '5');

  // CDRs cada N minutos (último día)
  cron.schedule(`*/${intervalMin} * * * *`, async () => {
    console.log('[CRON] Sincronización de CDRs (incremental)');
    await syncAllTenants(1);
  });

  // Sincronización completa diaria a las 3am: últimos 30 días
  cron.schedule('0 3 * * *', async () => {
    console.log('[CRON] Sincronización completa diaria (30 días)');
    await syncAllTenants(30);
  });

  // Primera sincronización al arrancar (después de 30 segundos)
  setTimeout(() => {
    console.log('[CRON] Sincronización inicial');
    syncAllTenants(7).catch(err => console.error('[CRON] Error en sync inicial:', err));
  }, 30000);
}

module.exports = { startScheduler };
