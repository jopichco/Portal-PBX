const db = require('../utils/db');
const { decrypt } = require('../utils/crypto');
const { PbxClient, formatPbxDate } = require('./pbxClient');

/**
 * Devuelve un cliente PBX configurado para un tenant
 */
async function getPbxClientForTenant(tenantId) {
  const { rows } = await db.query(
    'SELECT pbx_host, pbx_api_key_encrypted, pbx_server_id FROM tenants WHERE id = $1 AND is_active = true',
    [tenantId]
  );
  if (rows.length === 0) throw new Error('Tenant no encontrado');

  const tenant = rows[0];
  if (tenant.pbx_api_key_encrypted === 'PENDIENTE_CONFIGURAR') {
    throw new Error('API key del tenant no configurada');
  }

  return new PbxClient({
    host: tenant.pbx_host,
    apiKey: decrypt(tenant.pbx_api_key_encrypted),
    serverId: tenant.pbx_server_id,
  });
}

/**
 * Sincroniza departamentos del tenant
 */
async function syncDepartments(tenantId) {
  const client = await getPbxClientForTenant(tenantId);
  const departments = await client.listDepartments();

  let count = 0;
  for (const [pbxId, dept] of Object.entries(departments)) {
    await db.query(
      `INSERT INTO departments (tenant_id, pbx_department_id, name, last_synced)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
       ON CONFLICT (tenant_id, pbx_department_id)
       DO UPDATE SET name = EXCLUDED.name, last_synced = CURRENT_TIMESTAMP`,
      [tenantId, parseInt(pbxId), dept.name]
    );
    count++;
  }

  await updateSyncStatus(tenantId, 'departments', 'success', count);
  return count;
}

/**
 * Sincroniza extensiones del tenant
 */
async function syncExtensions(tenantId) {
  const client = await getPbxClientForTenant(tenantId);
  const extensions = await client.listExtensions();

  let count = 0;
  for (const [pbxId, ext] of Object.entries(extensions)) {
    const deptIds = ext.department
      ? ext.department.split(',').map(d => parseInt(d.trim())).filter(n => !isNaN(n))
      : [];

    await db.query(
      `INSERT INTO extensions (tenant_id, pbx_extension_id, extension_number, name, email, department_ids, status, last_synced)
       VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)
       ON CONFLICT (tenant_id, pbx_extension_id)
       DO UPDATE SET
         extension_number = EXCLUDED.extension_number,
         name = EXCLUDED.name,
         email = EXCLUDED.email,
         department_ids = EXCLUDED.department_ids,
         status = EXCLUDED.status,
         last_synced = CURRENT_TIMESTAMP`,
      [
        tenantId,
        parseInt(pbxId),
        ext.ext,
        ext.name,
        ext.email || null,
        deptIds,
        ext.status,
      ]
    );
    count++;
  }

  await updateSyncStatus(tenantId, 'extensions', 'success', count);
  return count;
}

/**
 * Sincroniza CDRs de los últimos N días para el tenant
 */
async function syncCdrs(tenantId, daysBack = 1) {
  const client = await getPbxClientForTenant(tenantId);

  const end = new Date();
  const start = new Date();
  start.setDate(start.getDate() - daysBack);

  const startStr = formatPbxDate(start);
  const endStr = formatPbxDate(end);

  // Mapa de extensión → primer departamento (para atribución)
  const { rows: extRows } = await db.query(
    'SELECT extension_number, department_ids FROM extensions WHERE tenant_id = $1',
    [tenantId]
  );
  const extToDept = {};
  for (const r of extRows) {
    if (r.department_ids && r.department_ids.length > 0) {
      extToDept[r.extension_number] = r.department_ids[0];
    }
  }

  let totalSynced = 0;
  let page = 1;
  let hasNext = true;

  while (hasNext) {
    const response = await client.downloadCdrs({
      start: startStr,
      end: endStr,
      page,
      limit: 1000,
      cdrtype: 3,
    });

    if (!response.csv || response.csv.length === 0) break;

    for (const row of response.csv) {
      // Orden de campos según documentación:
      // From, To, Date/Time (unix), Duration, Rating Duration, Rating Cost,
      // Status, UniqueID, Recording Path, Recording Available, Location Type, Caller ID, MOS
      const [from, to, timestamp, duration, billDur, cost, status,
             uniqueId, recPath, recAvail, locType, callerId, mos] = row;

      // Extraer número de extensión de strings tipo "Nombre (530)"
      const fromExt = extractExtension(from);
      const toExt = extractExtension(to);

      // Atribuir departamento al receptor de la llamada
      const deptId = (toExt && extToDept[toExt]) || (fromExt && extToDept[fromExt]) || null;

      // Determinar dirección
      let direction = 'Internal';
      if (locType === 'Remote' || (!fromExt && toExt)) direction = 'Incoming';
      else if (fromExt && !toExt) direction = 'Outgoing';
      else if (fromExt && toExt) direction = 'Internal';

      const ts = parseInt(timestamp);
      const dt = new Date(ts * 1000);

      await db.query(
        `INSERT INTO cdrs (
           tenant_id, unique_id, from_number, from_extension, to_number, to_extension,
           start_timestamp, start_datetime, duration, billing_duration, cost,
           status, direction, recording_path, recording_available,
           location_type, caller_id, mos, department_id
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
         ON CONFLICT (tenant_id, unique_id) DO NOTHING`,
        [
          tenantId, uniqueId, from, fromExt, to, toExt,
          ts, dt, parseInt(duration) || 0, parseInt(billDur) || 0, parseFloat(cost) || 0,
          status, direction, recPath || null, recAvail === 'True',
          locType, callerId, parseFloat(mos) || 0, deptId,
        ]
      );
      totalSynced++;
    }

    hasNext = response.next_page === true;
    page++;

    // Seguridad: máximo 50 páginas (50,000 registros) por ejecución
    if (page > 50) break;
  }

  await updateSyncStatus(tenantId, 'cdrs', 'success', totalSynced);
  return totalSynced;
}

function extractExtension(str) {
  if (!str) return null;
  const match = str.match(/\((\d+)\)\s*$/);
  return match ? match[1] : null;
}

async function updateSyncStatus(tenantId, type, status, count, error = null) {
  await db.query(
    `INSERT INTO sync_status (tenant_id, sync_type, last_sync_at, last_sync_status, records_synced, last_error)
     VALUES ($1, $2, CURRENT_TIMESTAMP, $3, $4, $5)
     ON CONFLICT (tenant_id, sync_type)
     DO UPDATE SET
       last_sync_at = CURRENT_TIMESTAMP,
       last_sync_status = EXCLUDED.last_sync_status,
       records_synced = EXCLUDED.records_synced,
       last_error = EXCLUDED.last_error`,
    [tenantId, type, status, count, error]
  );
}

/**
 * Sincronización completa de un tenant
 */
async function syncTenant(tenantId, daysBack = 1) {
  console.log(`[SYNC] Iniciando tenant ${tenantId}`);
  try {
    await syncDepartments(tenantId);
    await syncExtensions(tenantId);
    const cdrCount = await syncCdrs(tenantId, daysBack);
    console.log(`[SYNC] Tenant ${tenantId}: ${cdrCount} CDRs sincronizados`);
  } catch (err) {
    console.error(`[SYNC] Error en tenant ${tenantId}:`, err.message);
    await updateSyncStatus(tenantId, 'cdrs', 'failed', 0, err.message);
  }
}

/**
 * Sincroniza todos los tenants activos
 */
async function syncAllTenants(daysBack = 1) {
  const { rows } = await db.query(
    "SELECT id FROM tenants WHERE is_active = true AND pbx_api_key_encrypted != 'PENDIENTE_CONFIGURAR'"
  );
  for (const t of rows) {
    await syncTenant(t.id, daysBack);
  }
}

module.exports = { syncTenant, syncAllTenants, syncCdrs, syncDepartments, syncExtensions, getPbxClientForTenant };
