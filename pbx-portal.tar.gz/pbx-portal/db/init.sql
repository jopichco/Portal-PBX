-- =====================================================
-- Esquema del Portal Multi-Tenant PBX
-- =====================================================

-- Tabla de tenants (clientes del portal)
CREATE TABLE IF NOT EXISTS tenants (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    tenant_code VARCHAR(10) NOT NULL UNIQUE,
    pbx_server_id INTEGER NOT NULL,
    pbx_api_key_encrypted TEXT NOT NULL,
    pbx_host VARCHAR(255) NOT NULL,
    timezone VARCHAR(50) DEFAULT 'America/Tegucigalpa',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Usuarios del portal (login)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER REFERENCES tenants(id) ON DELETE CASCADE,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'viewer' CHECK (role IN ('admin', 'manager', 'viewer')),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, username),
    UNIQUE(tenant_id, email)
);

-- Departamentos sincronizados desde PBXware
CREATE TABLE IF NOT EXISTS departments (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER REFERENCES tenants(id) ON DELETE CASCADE,
    pbx_department_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    last_synced TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, pbx_department_id)
);

-- Extensiones sincronizadas
CREATE TABLE IF NOT EXISTS extensions (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER REFERENCES tenants(id) ON DELETE CASCADE,
    pbx_extension_id INTEGER NOT NULL,
    extension_number VARCHAR(20) NOT NULL,
    name VARCHAR(255),
    email VARCHAR(255),
    department_ids INTEGER[],  -- Array de IDs de departamento (de PBXware)
    status VARCHAR(20),
    last_synced TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, pbx_extension_id)
);

-- CDRs (Call Detail Records) sincronizados
CREATE TABLE IF NOT EXISTS cdrs (
    id BIGSERIAL PRIMARY KEY,
    tenant_id INTEGER REFERENCES tenants(id) ON DELETE CASCADE,
    unique_id VARCHAR(50) NOT NULL,
    from_number VARCHAR(100),
    from_extension VARCHAR(20),
    to_number VARCHAR(100),
    to_extension VARCHAR(20),
    start_timestamp BIGINT NOT NULL,
    start_datetime TIMESTAMP NOT NULL,
    duration INTEGER DEFAULT 0,
    billing_duration INTEGER DEFAULT 0,
    cost DECIMAL(10, 5) DEFAULT 0,
    status VARCHAR(20) NOT NULL,        -- Answered, Unanswered, Busy, Failed
    direction VARCHAR(20),               -- Incoming, Outgoing, Internal
    recording_path TEXT,
    recording_available BOOLEAN DEFAULT false,
    location_type VARCHAR(20),
    caller_id VARCHAR(255),
    mos DECIMAL(3, 1) DEFAULT 0,
    department_id INTEGER,               -- Atribución al primer departamento
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, unique_id)
);

-- Estado de sincronización por tenant
CREATE TABLE IF NOT EXISTS sync_status (
    id SERIAL PRIMARY KEY,
    tenant_id INTEGER REFERENCES tenants(id) ON DELETE CASCADE,
    sync_type VARCHAR(50) NOT NULL,      -- 'cdrs', 'extensions', 'departments'
    last_sync_at TIMESTAMP,
    last_sync_status VARCHAR(20),        -- 'success', 'partial', 'failed'
    last_error TEXT,
    records_synced INTEGER DEFAULT 0,
    UNIQUE(tenant_id, sync_type)
);

-- =====================================================
-- Índices para rendimiento
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_cdrs_tenant_date ON cdrs(tenant_id, start_datetime DESC);
CREATE INDEX IF NOT EXISTS idx_cdrs_tenant_status ON cdrs(tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_cdrs_tenant_direction ON cdrs(tenant_id, direction);
CREATE INDEX IF NOT EXISTS idx_cdrs_tenant_dept ON cdrs(tenant_id, department_id);
CREATE INDEX IF NOT EXISTS idx_cdrs_tenant_to_ext ON cdrs(tenant_id, to_extension);
CREATE INDEX IF NOT EXISTS idx_cdrs_tenant_from_ext ON cdrs(tenant_id, from_extension);
CREATE INDEX IF NOT EXISTS idx_extensions_tenant ON extensions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_extensions_number ON extensions(tenant_id, extension_number);
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);

-- =====================================================
-- Datos iniciales: tenant de ejemplo y usuario admin
-- IMPORTANTE: cambiar estos valores tras el primer login
-- =====================================================
-- La password en hash corresponde a: "admin123" (bcrypt)
-- Cambiala inmediatamente desde la interfaz
INSERT INTO tenants (name, tenant_code, pbx_server_id, pbx_api_key_encrypted, pbx_host)
VALUES ('Demo Tenant', '001', 2, 'PENDIENTE_CONFIGURAR', 'pbx.mifijo.com')
ON CONFLICT (tenant_code) DO NOTHING;

INSERT INTO users (tenant_id, username, email, password_hash, role)
VALUES (
    (SELECT id FROM tenants WHERE tenant_code = '001'),
    'admin',
    'admin@demo.local',
    '$2b$10$rZJYZqVqGqJrXJrYxZGqVeF3vJ8oXY5xqJrYxZGqVeF3vJ8oXY5xq',
    'admin'
)
ON CONFLICT DO NOTHING;
