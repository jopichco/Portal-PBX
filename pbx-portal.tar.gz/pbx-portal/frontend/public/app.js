// ============ Estado global ============
const API = '/api';
let authToken = localStorage.getItem('token');
let currentUser = JSON.parse(localStorage.getItem('user') || 'null');
let currentPeriod = 'month';
let callsPage = 1;
let charts = {};

// ============ Helpers ============
async function apiFetch(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      ...options.headers,
    },
  });
  if (res.status === 401) {
    logout();
    throw new Error('No autorizado');
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Error de red' }));
    throw new Error(err.error || 'Error');
  }
  return res.json();
}

function formatDuration(secs) {
  if (!secs) return '0:00';
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleString('es', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function destroyChart(key) {
  if (charts[key]) {
    charts[key].destroy();
    delete charts[key];
  }
}

// Paleta consistente con el mockup
const COLORS = ['#4a9eff', '#f59e0b', '#10b981', '#ef4444', '#a855f7', '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#6366f1'];

// ============ Auth ============
function showLogin() {
  document.getElementById('login-view').classList.remove('hidden');
  document.getElementById('dashboard-view').classList.add('hidden');
}

function showDashboard() {
  document.getElementById('login-view').classList.add('hidden');
  document.getElementById('dashboard-view').classList.remove('hidden');
  document.getElementById('tenant-name').textContent = currentUser.tenantName;
  document.getElementById('user-info').textContent = `${currentUser.username} (${currentUser.role})`;
  loadOverview();
}

async function login(e) {
  e.preventDefault();
  const tenantCode = document.getElementById('tenantCode').value;
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const errorDiv = document.getElementById('login-error');
  errorDiv.textContent = '';

  try {
    const res = await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tenantCode, username, password }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Login fallido');
    }
    const data = await res.json();
    authToken = data.token;
    currentUser = data.user;
    localStorage.setItem('token', authToken);
    localStorage.setItem('user', JSON.stringify(currentUser));
    showDashboard();
  } catch (err) {
    errorDiv.textContent = err.message;
  }
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  authToken = null;
  currentUser = null;
  showLogin();
}

// ============ Vista Overview ============
async function loadOverview() {
  try {
    const summary = await apiFetch('/dashboard/summary');
    document.getElementById('kpi-today').textContent = Number(summary.today).toLocaleString();
    document.getElementById('kpi-yesterday').textContent = Number(summary.yesterday).toLocaleString();
    document.getElementById('kpi-week').textContent = Number(summary.this_week).toLocaleString();
    document.getElementById('kpi-last-week').textContent = Number(summary.last_week).toLocaleString();
    document.getElementById('kpi-month').textContent = Number(summary.this_month).toLocaleString();
    document.getElementById('kpi-last-month').textContent = Number(summary.last_month).toLocaleString();

    await Promise.all([
      drawByDay(),
      drawStatus(summary),
      drawByHour(),
      drawByWeekday(),
    ]);
  } catch (err) {
    console.error('Error cargando overview:', err);
  }
}

async function drawByDay() {
  const data = await apiFetch('/dashboard/calls-by-day?days=30');
  destroyChart('byDay');
  charts.byDay = new Chart(document.getElementById('chart-by-day'), {
    type: 'line',
    data: {
      labels: data.map(d => new Date(d.date).toLocaleDateString('es', { month: 'short', day: 'numeric' })),
      datasets: [
        { label: 'Contestadas', data: data.map(d => d.answered), borderColor: COLORS[2], backgroundColor: COLORS[2] + '33', tension: 0.3, fill: true },
        { label: 'Perdidas', data: data.map(d => d.missed), borderColor: COLORS[3], backgroundColor: COLORS[3] + '33', tension: 0.3, fill: true },
      ],
    },
    options: chartOptions(),
  });
}

async function drawStatus(summary) {
  destroyChart('status');
  charts.status = new Chart(document.getElementById('chart-status'), {
    type: 'doughnut',
    data: {
      labels: ['Contestadas', 'Perdidas'],
      datasets: [{ data: [summary.answered_month, summary.missed_month], backgroundColor: [COLORS[2], COLORS[3]] }],
    },
    options: { ...chartOptions(), plugins: { legend: { position: 'bottom', labels: { color: '#8b9bb4' } } } },
  });
}

async function drawByHour() {
  const data = await apiFetch('/dashboard/calls-by-hour');
  destroyChart('byHour');
  const fullHours = Array.from({ length: 24 }, (_, i) => i);
  const counts = fullHours.map(h => {
    const found = data.find(d => d.hour === h);
    return found ? Number(found.total) : 0;
  });
  charts.byHour = new Chart(document.getElementById('chart-by-hour'), {
    type: 'bar',
    data: { labels: fullHours.map(h => `${h}h`), datasets: [{ data: counts, backgroundColor: COLORS[0] }] },
    options: { ...chartOptions(), plugins: { legend: { display: false } } },
  });
}

async function drawByWeekday() {
  const data = await apiFetch('/dashboard/calls-by-weekday');
  destroyChart('byWeekday');
  const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const ordered = days.map((_, i) => {
    const found = data.find(d => d.day_num === i);
    return found ? Number(found.total) : 0;
  });
  charts.byWeekday = new Chart(document.getElementById('chart-by-weekday'), {
    type: 'bar',
    data: { labels: days, datasets: [{ data: ordered, backgroundColor: COLORS[1] }] },
    options: { ...chartOptions(), plugins: { legend: { display: false } } },
  });
}

// ============ Vista Departamentos ============
async function loadDepartments() {
  const data = await apiFetch(`/dashboard/calls-by-department?period=${currentPeriod}`);

  destroyChart('departments');
  charts.departments = new Chart(document.getElementById('chart-departments'), {
    type: 'bar',
    data: {
      labels: data.map(d => d.department),
      datasets: [
        { label: 'Contestadas', data: data.map(d => Number(d.answered)), backgroundColor: COLORS[2] },
        { label: 'Perdidas', data: data.map(d => Number(d.missed)), backgroundColor: COLORS[3] },
      ],
    },
    options: { ...chartOptions(), scales: { x: { stacked: true, ticks: { color: '#8b9bb4' } }, y: { stacked: true, ticks: { color: '#8b9bb4' } } } },
  });

  const tbody = document.querySelector('#table-departments tbody');
  tbody.innerHTML = data.map(d => `
    <tr>
      <td>${d.department}</td>
      <td>${d.total}</td>
      <td>${d.answered}</td>
      <td>${d.missed}</td>
      <td>${d.incoming}</td>
      <td>${d.outgoing}</td>
      <td>${formatDuration(d.avg_duration)}</td>
    </tr>
  `).join('');
}

// ============ Vista Usuarios ============
async function loadUsers() {
  const data = await apiFetch(`/dashboard/calls-by-user?period=${currentPeriod}&limit=20`);

  destroyChart('users');
  charts.users = new Chart(document.getElementById('chart-users'), {
    type: 'bar',
    data: {
      labels: data.map(u => `${u.user_name} (${u.extension_number})`),
      datasets: [
        { label: 'Recibidas', data: data.map(u => Number(u.received)), backgroundColor: COLORS[0] },
        { label: 'Realizadas', data: data.map(u => Number(u.made)), backgroundColor: COLORS[1] },
      ],
    },
    options: { ...chartOptions(), indexAxis: 'y' },
  });

  const tbody = document.querySelector('#table-users tbody');
  tbody.innerHTML = data.map(u => `
    <tr>
      <td>${u.extension_number}</td>
      <td>${u.user_name || '-'}</td>
      <td>${u.received}</td>
      <td>${u.made}</td>
      <td>${u.answered}</td>
      <td>${u.missed}</td>
      <td>${formatDuration(u.avg_duration)}</td>
    </tr>
  `).join('');
}

// ============ Vista Llamadas ============
async function loadCalls() {
  const ext = document.getElementById('calls-filter-ext').value;
  const status = document.getElementById('calls-filter-status').value;
  const direction = document.getElementById('calls-filter-direction').value;

  const params = new URLSearchParams({ page: callsPage, limit: 50 });
  if (ext) params.set('extension', ext);
  if (status) params.set('status', status);
  if (direction) params.set('direction', direction);

  const result = await apiFetch(`/calls?${params}`);

  const tbody = document.querySelector('#table-calls tbody');
  tbody.innerHTML = result.data.map(c => `
    <tr>
      <td>${formatDate(c.start_datetime)}</td>
      <td>${c.from_number || '-'}</td>
      <td>${c.to_number || '-'}</td>
      <td>${c.direction || '-'}</td>
      <td><span class="status-badge status-${c.status}">${c.status}</span></td>
      <td>${formatDuration(c.duration)}</td>
      <td>${c.department_name || '-'}</td>
    </tr>
  `).join('');

  const totalPages = Math.ceil(result.total / result.limit);
  document.getElementById('page-info').textContent = `Página ${callsPage} de ${totalPages} (${result.total} llamadas)`;
  document.getElementById('page-prev').disabled = callsPage <= 1;
  document.getElementById('page-next').disabled = callsPage >= totalPages;
}

// ============ Opciones comunes Chart.js ============
function chartOptions() {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: '#8b9bb4' } },
      tooltip: { backgroundColor: '#1a2332', borderColor: '#2d3a4f', borderWidth: 1 },
    },
    scales: {
      x: { ticks: { color: '#8b9bb4' }, grid: { color: '#2d3a4f' } },
      y: { ticks: { color: '#8b9bb4' }, grid: { color: '#2d3a4f' }, beginAtZero: true },
    },
  };
}

// ============ Navegación ============
function switchView(view) {
  document.querySelectorAll('.nav-item').forEach(a => a.classList.toggle('active', a.dataset.view === view));
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`view-${view}`).classList.add('active');
  document.getElementById('view-title').textContent = {
    overview: 'Overview', departments: 'Por Departamento', users: 'Por Usuario', calls: 'Llamadas',
  }[view];

  if (view === 'overview') loadOverview();
  if (view === 'departments') loadDepartments();
  if (view === 'users') loadUsers();
  if (view === 'calls') { callsPage = 1; loadCalls(); }
}

// ============ Event listeners ============
document.getElementById('login-form').addEventListener('submit', login);
document.getElementById('logout-btn').addEventListener('click', logout);
document.getElementById('refresh-btn').addEventListener('click', () => {
  const activeView = document.querySelector('.nav-item.active').dataset.view;
  switchView(activeView);
});
document.getElementById('period-filter').addEventListener('change', e => {
  currentPeriod = e.target.value;
  const activeView = document.querySelector('.nav-item.active').dataset.view;
  if (activeView !== 'overview' && activeView !== 'calls') switchView(activeView);
});
document.querySelectorAll('.nav-item').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    switchView(a.dataset.view);
  });
});
document.getElementById('apply-calls-filter').addEventListener('click', () => { callsPage = 1; loadCalls(); });
document.getElementById('page-prev').addEventListener('click', () => { callsPage--; loadCalls(); });
document.getElementById('page-next').addEventListener('click', () => { callsPage++; loadCalls(); });

// ============ Inicio ============
if (authToken && currentUser) {
  showDashboard();
} else {
  showLogin();
}
